package com.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    TextView input, signbox;

    String sign, value1, value2;
    Double num1, num2, result;
    boolean hasDot;

    private static final String KEY_VALUE1 = "VALUE1";
    private static final String KEY_VALUE2 = "VALUE2";
    private static final String KEY_SIGN = "SIGN";
    private static final String KEY_HASDOT = "HASDOT";
    private static final String KEY_INPUT = "INPUT";

    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = (TextView) findViewById(R.id.input);
        signbox = (TextView) findViewById(R.id.output);

        hasDot = false;

        if (savedInstanceState!= null)
        {

            value1 = savedInstanceState.getString(KEY_VALUE1, "");
            value2 = savedInstanceState.getString(KEY_VALUE2, "");
            sign = savedInstanceState.getString(KEY_SIGN, "");
            hasDot = savedInstanceState.getBoolean(KEY_HASDOT, false);
            String lastOut = savedInstanceState.getString(KEY_INPUT);
            signbox.setText(sign);
            input.setText(lastOut);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        String lastOut = input.getText().toString();

        super.onSaveInstanceState(outState);
        outState.putString(KEY_VALUE1, value1);
        outState.putString(KEY_VALUE2, value2);
        outState.putString(KEY_SIGN, sign);
        outState.putBoolean(KEY_HASDOT, hasDot);
        outState.putString(KEY_INPUT, lastOut);
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_0(View view)
    {
        input.setText(input.getText()+"0");
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_1(View view)
    {
        input.setText(input.getText()+"1");
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_2(View view)
    {
        input.setText(input.getText()+"2");
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_3(View view)
    {
        input.setText(input.getText()+"3");
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_4(View view)
    {
        input.setText(input.getText()+"4");
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_5(View view)
    {
        input.setText(input.getText()+"5");
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_6(View view)
    {
        input.setText(input.getText()+"6");
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_7(View view)
    {
        input.setText(input.getText()+"7");
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_8(View view)
    {
        input.setText(input.getText()+"8");
    }

    @SuppressLint("SetTextI18n")
    public void btnClick_9(View view)
    {
        input.setText(input.getText()+"9");
    }

    public void btnClick_plus(View view)
    {
        sign = "+";
        value1 = input.getText().toString();
        input.setText(null);
        signbox.setText("+");
        hasDot = false;
    }

    public void btnClick_minus(View view) {
        sign = "-";
        value1 = input.getText().toString();
        input.setText(null);
        signbox.setText("-");
        hasDot = false;
    }

    public void btnClick_multiply(View view) {
        sign = "*";
        value1 = input.getText().toString();
        input.setText(null);
        signbox.setText("×");
        hasDot = false;
    }

    public void btnClick_divide(View view) {
        sign = "/";
        value1 = input.getText().toString();
        input.setText(null);
        signbox.setText("÷");
        hasDot = false;
    }

    //---------------------------------------

    public void btnClick_percent(View view)
    {
        sign = "percent";
        value1 = input.getText().toString();
        input.setText(null);
        signbox.setText("%");
        hasDot = false;
    }

    public void btnClick_back(View view)
    {
        sign = "back";
        input.setText(null);
        hasDot = false;
        signbox.setText("1/x");
    }

    public void btnClick_Pi(View view)
    {
        input.setText(input.getText()+ (Math.PI + ""));
    }

    public void btnClick_E(View view)
    {
        input.setText(input.getText()+"2.718281828459");
    }

    //-------------------------------------------

    public void btnClick_clear(View view)
    {
        input.setText(null);
        signbox.setText(null);
        value1 = null;
        value2 = null;
        sign = null;
        hasDot = false;
    }

    public void btnClick_delete(View view)
    {
        if (input.getText().equals("")) {
            input.setText(null);
        } else {
            int len = input.getText().length();
            String s = input.getText().toString();
            if (s.charAt(len - 1) == '.') {
                hasDot = false;
                input.setText(input.getText().subSequence(0, input.getText().length() - 1));

            } else {
                input.setText(input.getText().subSequence(0, input.getText().length() - 1));
            }
        }
    }

    public void btnClick_dot(View view)
    {
        if (!hasDot) {
            if (input.getText().equals("")) {

                input.setText("0.");
            } else {

                input.setText(input.getText() + ".");
            }

            hasDot = true;
        }

    }

    public void btnClick_equal(View view)
    {
        if (sign == null)
        {
            signbox.setText("Error!");
        } else if (input.getText().equals(""))
        {
            signbox.setText("Error!");
        } else if ((sign.equals("+") || sign.equals("-") || sign.equals("*") || sign.equals("/")|| sign.equals("power")|| sign.equals("log") || sign.equals("percent")) && value1.equals(""))
        {
            signbox.setText("Error!");
        } else
            {
            switch (sign)
            {
                default:
                    break;
                case "log":
                    num1 = Double.parseDouble(value1);
                    input.setText(Math.log10(num1) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "ln":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble(value1);
                    input.setText(Math.log(num1) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "back":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    num1 = 1/num1;
                    input.setText(num1 + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "power":
                    num1 = Double.parseDouble((value1));
                    value2 = input.getText().toString();
                    num2 = Double.parseDouble(value2);
                    input.setText(Math.pow(num1, num2) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "percent":
                    value2 = input.getText().toString();
                    if (value2.equals(""))
                    {
                        num1 = Double.parseDouble(value1);
                        result = (num1)/100;
                    }
                    else
                        {
                        num1 = Double.parseDouble(value1);
                        num2 = Double.parseDouble(value2);
                        result = (num1 * num2)/100;
                    }

                    input.setText(result + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "root":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    input.setText(Math.sqrt(num1) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "factorial":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    int i = Integer.parseInt(value1) - 1;

                    while (i > 0) {
                        num1 = num1 * i;
                        i--;
                    }

                    input.setText(num1 + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "sin":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    input.setText(Math.sin(num1) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "cos":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    input.setText(Math.cos(num1) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "tg":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    input.setText(Math.tan(num1) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "ctg":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    input.setText(1/(Math.tan(num1)) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "+":
                    value2 = input.getText().toString();
                    num1 = Double.parseDouble(value1);
                    num2 = Double.parseDouble(value2);
                    result = num1 + num2;
                    input.setText(result + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "-":
                    value2 = input.getText().toString();
                    num1 = Double.parseDouble(value1);
                    num2 = Double.parseDouble(value2);
                    result = num1 - num2;
                    input.setText(result + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "*":
                    value2 = input.getText().toString();
                    num1 = Double.parseDouble(value1);
                    num2 = Double.parseDouble(value2);
                    result = num1 * num2;
                    input.setText(result + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "/":
                    value2 = input.getText().toString();
                    num1 = Double.parseDouble(value1);
                    num2 = Double.parseDouble(value2);
                    result = num1 / num2;
                    input.setText(result + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "arcsin":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    input.setText(Math.asin(num1) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "arccos":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    input.setText(Math.acos(num1) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "arctg":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    input.setText(Math.atan(num1) + "");
                    sign = null;
                    signbox.setText(null);
                    break;
                case "arcctg":
                    value1 = input.getText().toString();
                    num1 = Double.parseDouble((value1));
                    input.setText(Math.atan(-num1)+ Math.PI/2 + "");
                    sign = null;
                    signbox.setText(null);
                    break;
            }

        }
    }
//--------------------------------------------------------------------------------
    public void btnClick_sin(View view)
    {
        sign = "sin";
        input.setText(null);
        hasDot = false;
        signbox.setText("sin");
    }

    public void btnClick_cos(View view)
    {
        sign = "cos";
        input.setText(null);
        hasDot = false;
        signbox.setText("cos");
    }

    public void btnClick_tg(View view)
    {
        sign = "tg";
        input.setText(null);
        hasDot = false;
        signbox.setText("tg");
    }

    public void btnClick_ctg(View view)
    {
        sign = "ctg";
        input.setText(null);
        hasDot = false;
        signbox.setText("ctg");
    }

    public void btnClick_log(View view)
    {
        value1 = input.getText().toString();
        sign = "log";
        input.setText(null);
        signbox.setText("log");
        hasDot = false;
    }

    public void btnClick_ln(View view)
    {
        sign = "ln";
        input.setText(null);
        signbox.setText("ln");
        hasDot = false;
    }

    public void btnClick_power(View view)
    {
        sign = "power";
        value1 = input.getText().toString();
        input.setText(null);
        hasDot = false;
        signbox.setText("xⁿ");
    }

    public void btnClick_root(View view)
    {
        sign = "root";
        input.setText(null);
        hasDot = false;
        signbox.setText("√");
    }

    public void btnClick_factorial(View view)
    {
        sign = "factorial";
        input.setText(null);
        hasDot = false;
        signbox.setText("!");
    }
    public void btnClick_arcsin(View view)
    {
        sign = "arcsin";
        input.setText(null);
        hasDot = false;
        signbox.setText("arcsin");
    }

    public void btnClick_arccos(View view)
    {
        sign = "arccos";
        input.setText(null);
        hasDot = false;
        signbox.setText("arccos");
    }

    public void btnClick_arctg(View view)
    {
        sign = "arctg";
        input.setText(null);
        hasDot = false;
        signbox.setText("arctg");
    }

    public void btnClick_arcctg(View view)
    {
        sign = "arcctg";
        input.setText(null);
        hasDot = false;
        signbox.setText("arcctg");
    }
}
